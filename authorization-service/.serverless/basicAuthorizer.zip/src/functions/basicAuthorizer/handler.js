var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/basicAuthorizer/handler.ts
var handler_exports = {};
__export(handler_exports, {
  main: () => main
});
module.exports = __toCommonJS(handler_exports);
var basicAuthorizer = async (event) => {
  const { authorizationToken, methodArn } = event;
  if (event.type !== "TOKEN") {
    return generatePolicy(authorizationToken, methodArn, "Deny" /* DENY */);
  }
  try {
    const userCreds = getUserCredentialsFromToken(authorizationToken);
    const password = process.env[userCreds.username];
    const effect = password && password === userCreds.password ? "Allow" /* ALLOW */ : "Deny" /* DENY */;
    return generatePolicy(authorizationToken, methodArn, effect);
  } catch (error) {
    return generatePolicy(authorizationToken, methodArn, "Deny" /* DENY */);
  }
};
function getUserCredentialsFromToken(authorizationToken) {
  const token = authorizationToken.split(" ")[1];
  const [username, password] = Buffer.from(token, "base64").toString("utf-8").split(":");
  return {
    username,
    password
  };
}
function generatePolicy(principalId, resource, effect = "Allow" /* ALLOW */) {
  return {
    principalId,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: resource
        }
      ]
    }
  };
}
var main = basicAuthorizer;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=handler.js.map
